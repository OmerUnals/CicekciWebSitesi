    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-logo">Gül Bahçesi</div>
                <div class="footer-links">
                    <a href="index.php">Ana Sayfa</a>
                    <a href="urunler.php">Ürünler</a>
                    <a href="iletisim.php">İletişim</a>
                </div>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                </div>
            </div>
            <p class="copyright">&copy; 2026 Gül Bahçesi. Tüm hakları saklıdır.</p>
        </div>
    </footer>
    <script src="script.js"></script>
</body>
</html>
